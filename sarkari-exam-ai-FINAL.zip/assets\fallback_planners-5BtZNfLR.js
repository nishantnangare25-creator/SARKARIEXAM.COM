var e=[{exam:`UPSC Civil Services`,level:`Beginner`,hours:`8`,content:`### Master Study Plan: UPSC Civil Services (Beginner)

**Week 1-2: Foundations**
- Read NCERTs from Class 6 to 12 (History, Geography, Polity).
- Daily newspaper reading (The Hindu or Indian Express).

**Week 3-4: Core Subjects**
- Laxmikanth for Indian Polity.
- Spectrum for Modern History.

**Daily Schedule (8 Hours)**
- 08:00 AM - 10:00 AM: Current Affairs & Newspaper
- 10:30 AM - 01:30 PM: Core Subject 1 (Polity/History)
- 02:30 PM - 05:30 PM: Core Subject 2 (Geography/Economy)
- 06:00 PM - 08:00 PM: Revision & Note-making

*This is an offline generated study plan.*`},{exam:`SSC CGL`,level:`Beginner`,hours:`6`,content:`### Master Study Plan: SSC CGL (Beginner)

**Focus Areas:**
- Quantitative Aptitude, Reasoning, General English, General Awareness.

**Daily Schedule (6 Hours)**
- 09:00 AM - 11:00 AM: Quantitative Aptitude (Start with Arithmetic)
- 11:15 AM - 01:15 PM: Reasoning & Logic
- 02:30 PM - 03:30 PM: General Awareness & Current Affairs
- 04:00 PM - 05:00 PM: English Language & Comprehension

*This is an offline generated study plan.*`}],t={planners:e};export{t as default,e as planners};